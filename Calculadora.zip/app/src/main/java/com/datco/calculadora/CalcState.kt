package com.datco.calculadora

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class HistoryItem(val expr: String, val result: String)

class CalcState(private val prefs: SharedPreferences) {

    var expr by mutableStateOf("")
    var lastExpr by mutableStateOf("")
    var justEvaluated by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var degrees by mutableStateOf(prefs.getBoolean("deg", true))
    var second by mutableStateOf(false)
    var memory by mutableStateOf(prefs.getString("mem", "0")?.toDoubleOrNull() ?: 0.0)
    var ans by mutableStateOf(0.0)
    val history = mutableStateListOf<HistoryItem>()

    init {
        prefs.getString("hist", "")?.lines()?.forEach { line ->
            val p = line.split("\t")
            if (p.size == 2) history.add(HistoryItem(p[0], p[1]))
        }
    }

    private fun startFresh() {
        if (justEvaluated) {
            expr = ""
            lastExpr = ""
            justEvaluated = false
        }
        error = null
    }

    fun insert(t: String) {
        startFresh()
        if (t.first().isLetter() && expr.isNotEmpty() && expr.last().isLetter()) expr += "×"
        expr += t
    }

    fun dot() {
        startFresh()
        val tail = expr.takeLastWhile { it.isDigit() || it == '.' }
        if (tail.contains('.')) return
        expr += if (tail.isEmpty()) "0." else "."
    }

    fun op(o: String) {
        error = null
        if (justEvaluated) {
            justEvaluated = false
            lastExpr = ""
        }
        if (expr.isEmpty()) {
            expr = if (o == "−") "−" else "Ans$o"
            return
        }
        if (expr == "−") return
        val last = expr.last()
        if (last in "+−×÷^") {
            if (o == "−" && last in "×÷^") expr += o
            else expr = expr.dropLast(1) + o
        } else {
            expr += o
        }
    }

    fun postfix(t: String) {
        if (expr.isEmpty()) return
        if (t == ")" && expr.count { it == '(' } <= expr.count { it == ')' }) return
        error = null
        if (justEvaluated) {
            justEvaluated = false
            lastExpr = ""
        }
        expr += t
    }

    fun backspace() {
        error = null
        if (justEvaluated) {
            justEvaluated = false
            lastExpr = ""
        }
        val tokens = listOf("asin(", "acos(", "atan(", "sin(", "cos(", "tan(", "ln(", "log(", "√(", "Ans")
        val t = tokens.firstOrNull { expr.endsWith(it) }
        expr = if (t != null) expr.dropLast(t.length) else expr.dropLast(1)
    }

    fun clear() {
        expr = ""
        lastExpr = ""
        justEvaluated = false
        error = null
    }

    private fun value(): Double? = try {
        if (expr.isEmpty()) null else CalcEngine.eval(expr, degrees, ans)
    } catch (e: Exception) {
        null
    }

    fun preview(): String {
        if (justEvaluated || expr.isEmpty() || expr.toDoubleOrNull() != null) return ""
        val v = value() ?: return ""
        return "= " + CalcEngine.format(v)
    }

    fun equals() {
        if (expr.isEmpty() || justEvaluated) return
        try {
            val v = CalcEngine.eval(expr, degrees, ans)
            val f = CalcEngine.format(v)
            history.add(0, HistoryItem(expr, f))
            if (history.size > 100) history.removeAt(history.lastIndex)
            ans = v
            lastExpr = "$expr ="
            expr = f
            justEvaluated = true
            error = null
            save()
        } catch (e: CalcException) {
            error = e.message
        } catch (e: Exception) {
            error = "Error"
        }
    }

    fun toggleDegrees() {
        degrees = !degrees
        save()
    }

    // Memoria
    private fun current(): Double? = if (justEvaluated) ans else value()

    fun mAdd(sign: Int) {
        current()?.let {
            memory += sign * it
            save()
        }
    }

    fun mClear() {
        memory = 0.0
        save()
    }

    fun mRecall() {
        startFresh()
        val f = CalcEngine.format(memory)
        val t = if (memory < 0) "($f)" else f
        if (expr.isNotEmpty() && (expr.last().isLetterOrDigit() || expr.last() == ')' || expr.last() == '.')) expr += "×"
        expr += t
    }

    fun clearHistory() {
        history.clear()
        save()
    }

    private fun save() {
        prefs.edit()
            .putString("mem", memory.toString())
            .putBoolean("deg", degrees)
            .putString("hist", history.joinToString("\n") { it.expr + "\t" + it.result })
            .apply()
    }
}
