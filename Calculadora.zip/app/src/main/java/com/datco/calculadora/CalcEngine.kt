package com.datco.calculadora

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.*

class CalcException(message: String) : Exception(message)

object CalcEngine {

    fun eval(src: String, degrees: Boolean, ans: Double): Double {
        val open = src.count { it == '(' } - src.count { it == ')' }
        val full = if (open > 0) src + ")".repeat(open) else src
        val v = Parser(full, degrees, ans).parse()
        if (v.isNaN() || v.isInfinite()) throw CalcException("Error")
        return v
    }

    fun format(value: Double): String {
        if (abs(value) < 1e-14) return "0"
        val r = BigDecimal(value).round(MathContext(12)).stripTrailingZeros()
        val a = abs(value)
        return if (a >= 1e12 || a < 1e-6) r.toString() else r.toPlainString()
    }
}

private class Parser(
    private val s: String,
    private val deg: Boolean,
    private val ans: Double
) {
    private var i = 0

    fun parse(): Double {
        val v = expr()
        if (i < s.length) throw CalcException("Error")
        return v
    }

    private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

    private fun expr(): Double {
        var v = term()
        while (true) {
            when (peek()) {
                '+' -> { i++; v += term() }
                '−', '-' -> { i++; v -= term() }
                else -> return v
            }
        }
    }

    private fun term(): Double {
        var v = unary()
        while (true) {
            val c = peek()
            when {
                c == '×' || c == '*' -> { i++; v *= unary() }
                c == '÷' || c == '/' -> {
                    i++
                    val d = unary()
                    if (d == 0.0) throw CalcException("No se puede dividir por 0")
                    v /= d
                }
                c.isDigit() || c == '.' || c == '(' || c.isLetter() || c == '√' -> v *= unary()
                else -> return v
            }
        }
    }

    private fun unary(): Double = when (peek()) {
        '−', '-' -> { i++; -unary() }
        '+' -> { i++; unary() }
        else -> power()
    }

    private fun power(): Double {
        val base = postfix()
        if (peek() == '^') {
            i++
            return base.pow(unary())
        }
        return base
    }

    private fun postfix(): Double {
        var v = primary()
        while (true) {
            when (peek()) {
                '!' -> { i++; v = factorial(v) }
                '%' -> { i++; v /= 100.0 }
                else -> return v
            }
        }
    }

    private fun primary(): Double {
        val c = peek()
        return when {
            c.isDigit() || c == '.' -> number()
            c == '(' -> {
                i++
                val v = expr()
                if (peek() == ')') i++
                v
            }
            c == 'π' -> { i++; PI }
            c == '√' -> {
                i++
                val a = primary()
                if (a < 0) throw CalcException("Error")
                sqrt(a)
            }
            c.isLetter() -> identifier()
            else -> throw CalcException("Error")
        }
    }

    private fun number(): Double {
        val start = i
        while (peek().isDigit() || peek() == '.') i++
        if (peek() == 'E') {
            val n = s.getOrNull(i + 1)
            if (n != null && (n.isDigit() || n == '+' || n == '-')) {
                i++
                if (peek() == '+' || peek() == '-') i++
                while (peek().isDigit()) i++
            }
        }
        return s.substring(start, i).toDoubleOrNull() ?: throw CalcException("Error")
    }

    private fun identifier(): Double {
        val start = i
        while (peek().isLetter() && peek() != 'π') i++
        val name = s.substring(start, i)
        if (name == "e") return E
        if (name == "Ans") return ans
        if (peek() != '(') throw CalcException("Error")
        i++
        val a = expr()
        if (peek() == ')') i++
        return func(name, a)
    }

    private fun func(n: String, a: Double): Double {
        fun rad(x: Double) = if (deg) Math.toRadians(x) else x
        fun back(x: Double) = if (deg) Math.toDegrees(x) else x
        return when (n) {
            "sin" -> sin(rad(a))
            "cos" -> cos(rad(a))
            "tan" -> {
                if (deg && abs(a % 180.0) == 90.0) throw CalcException("Error")
                tan(rad(a))
            }
            "asin" -> { if (a < -1 || a > 1) throw CalcException("Error"); back(asin(a)) }
            "acos" -> { if (a < -1 || a > 1) throw CalcException("Error"); back(acos(a)) }
            "atan" -> back(atan(a))
            "ln" -> { if (a <= 0) throw CalcException("Error"); ln(a) }
            "log" -> { if (a <= 0) throw CalcException("Error"); log10(a) }
            else -> throw CalcException("Error")
        }
    }

    private fun factorial(v: Double): Double {
        if (v < 0 || v != floor(v) || v > 170) throw CalcException("Error")
        var r = 1.0
        for (k in 2..v.toInt()) r *= k
        return r
    }
}
