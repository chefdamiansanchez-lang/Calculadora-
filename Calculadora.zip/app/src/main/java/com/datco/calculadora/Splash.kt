package com.datco.calculadora

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DatcoSplash(onFinished: () -> Unit) {
    val fade = remember { Animatable(0f) }
    val grow = remember { Animatable(0.85f) }

    LaunchedEffect(Unit) {
        launch { fade.animateTo(1f, tween(900)) }
        launch { grow.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
        delay(2400)
        onFinished()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFF1B2028)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.graphicsLayer {
                alpha = fade.value
                scaleX = grow.value
                scaleY = grow.value
            }
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))),
                contentAlignment = Alignment.Center
            ) {
                Text("D", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(24.dp))
            Text("DATCO", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 10.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías y Códigos Operativos",
                color = Color(0xFF8FA3B8),
                fontSize = 11.sp,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 32.dp)
            )
        }
        Text(
            "Diseño de apps... y algo más",
            color = Color(0xFF6C7F94),
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp)
                .graphicsLayer { alpha = fade.value }
        )
    }
}
