package com.datco.calculadora

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BgTop = Color(0xFF08153A)
private val BgBottom = Color(0xFF0D3B8E)
private val DigitBg = Color(0xFF2468E0)
private val OpBg = Color(0xFF0A2C74)
private val Glass = Color(0x26FFFFFF)
private val Cyan = Color(0xFF00D2FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val state = remember { CalcState(getSharedPreferences("calc", MODE_PRIVATE)) }
                var splash by remember { mutableStateOf(true) }
                Crossfade(targetState = splash, animationSpec = tween(500), label = "root") { showSplash ->
                    if (showSplash) DatcoSplash { splash = false } else CalculatorScreen(state)
                }
            }
        }
    }
}

@Composable
fun RoundKey(label: String, modifier: Modifier, bg: Color, fg: Color, size: TextUnit, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    BoxWithConstraints(modifier = modifier.fillMaxHeight(), contentAlignment = Alignment.Center) {
        val d = minOf(maxWidth, maxHeight) * 0.92f
        Box(
            modifier = Modifier
                .size(d)
                .clip(CircleShape)
                .background(bg)
                .clickable {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                },
            contentAlignment = Alignment.Center
        ) {
            Text(label, color = fg, fontSize = size, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun PillKey(label: String, modifier: Modifier, bg: Color, fg: Color, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    Box(
        modifier = modifier
            .fillMaxHeight()
            .padding(3.dp)
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = fg, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun RowScope.DigitKey(label: String, onClick: () -> Unit) =
    RoundKey(label, Modifier.weight(1f), DigitBg, Color.White, 34.sp, onClick)

@Composable
private fun RowScope.OpKey(label: String, onClick: () -> Unit) =
    RoundKey(label, Modifier.weight(1f), OpBg, Cyan, 34.sp, onClick)

@Composable
private fun RowScope.FuncKey(label: String, fg: Color = Color.White, onClick: () -> Unit) =
    RoundKey(label, Modifier.weight(1f), Glass, fg, 26.sp, onClick)

@Composable
fun Display(state: CalcState, modifier: Modifier) {
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    val err = state.error
    val small = when {
        err != null -> err
        state.justEvaluated -> state.lastExpr
        else -> state.preview()
    }
    val big = state.expr.ifEmpty { "0" }
    val fs = when {
        big.length <= 8 -> 68.sp
        big.length <= 12 -> 52.sp
        big.length <= 18 -> 38.sp
        else -> 28.sp
    }
    Column(
        modifier = modifier
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = {
                    clipboard.setText(AnnotatedString(state.expr))
                    Toast.makeText(ctx, "Copiado", Toast.LENGTH_SHORT).show()
                })
            }
            .padding(horizontal = 8.dp),
        horizontalAlignment = Alignment.End
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(if (state.degrees) "DEG" else "RAD", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (state.memory != 0.0) {
                Text("M", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.weight(1f))
        Text(
            small,
            color = if (err != null) Color(0xFFFF8A80) else Color(0xFF9FC3FF),
            fontSize = 22.sp,
            maxLines = 1
        )
        Text(
            big,
            color = Color.White,
            fontSize = fs,
            fontWeight = FontWeight.Light,
            maxLines = 2,
            textAlign = TextAlign.End
        )
    }
}

@Composable
fun CalculatorScreen(state: CalcState) {
    var showHistory by remember { mutableStateOf(false) }
    BackHandler(enabled = showHistory) { showHistory = false }
    val sec = state.second

    fun fn(t: String) {
        state.insert(t)
        state.second = false
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BgTop, BgBottom)))) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Display(state, Modifier.weight(1.3f).fillMaxWidth())

            // Memoria
            Row(Modifier.fillMaxWidth().height(36.dp)) {
                PillKey("MC", Modifier.weight(1f), Color.Transparent, Cyan) { state.mClear() }
                PillKey("MR", Modifier.weight(1f), Color.Transparent, Cyan) { state.mRecall() }
                PillKey("M+", Modifier.weight(1f), Color.Transparent, Cyan) { state.mAdd(1) }
                PillKey("M−", Modifier.weight(1f), Color.Transparent, Cyan) { state.mAdd(-1) }
                PillKey("Historial", Modifier.weight(1.5f), Glass, Color.White) { showHistory = true }
            }

            // Científica
            Column(Modifier.weight(1.05f).fillMaxWidth()) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    PillKey("2nd", Modifier.weight(1f), if (sec) Cyan else Glass, if (sec) BgTop else Color.White) {
                        state.second = !state.second
                    }
                    PillKey(if (state.degrees) "DEG" else "RAD", Modifier.weight(1f), Glass, Color.White) {
                        state.toggleDegrees()
                    }
                    PillKey(if (sec) "asin" else "sin", Modifier.weight(1f), Glass, Color.White) {
                        fn(if (sec) "asin(" else "sin(")
                    }
                    PillKey(if (sec) "acos" else "cos", Modifier.weight(1f), Glass, Color.White) {
                        fn(if (sec) "acos(" else "cos(")
                    }
                    PillKey(if (sec) "atan" else "tan", Modifier.weight(1f), Glass, Color.White) {
                        fn(if (sec) "atan(" else "tan(")
                    }
                }
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    PillKey(if (sec) "e^x" else "ln", Modifier.weight(1f), Glass, Color.White) {
                        fn(if (sec) "e^(" else "ln(")
                    }
                    PillKey(if (sec) "10^x" else "log", Modifier.weight(1f), Glass, Color.White) {
                        fn(if (sec) "10^(" else "log(")
                    }
                    PillKey("√", Modifier.weight(1f), Glass, Color.White) { fn("√(") }
                    PillKey(if (sec) "x³" else "x²", Modifier.weight(1f), Glass, Color.White) {
                        state.postfix(if (sec) "^3" else "^2")
                        state.second = false
                    }
                    PillKey("x^y", Modifier.weight(1f), Glass, Color.White) { state.op("^") }
                }
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    PillKey("π", Modifier.weight(1f), Glass, Color.White) { fn("π") }
                    PillKey("e", Modifier.weight(1f), Glass, Color.White) { fn("e") }
                    PillKey("(", Modifier.weight(1f), Glass, Color.White) { fn("(") }
                    PillKey(")", Modifier.weight(1f), Glass, Color.White) { state.postfix(")") }
                    PillKey("n!", Modifier.weight(1f), Glass, Color.White) { state.postfix("!") }
                }
            }

            // Teclado principal
            Column(Modifier.weight(3.9f).fillMaxWidth()) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    FuncKey("AC", Color(0xFFFF8A80)) { state.clear() }
                    FuncKey("←") { state.backspace() }
                    FuncKey("%") { state.postfix("%") }
                    OpKey("÷") { state.op("÷") }
                }
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    DigitKey("7") { state.insert("7") }
                    DigitKey("8") { state.insert("8") }
                    DigitKey("9") { state.insert("9") }
                    OpKey("×") { state.op("×") }
                }
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    DigitKey("4") { state.insert("4") }
                    DigitKey("5") { state.insert("5") }
                    DigitKey("6") { state.insert("6") }
                    OpKey("−") { state.op("−") }
                }
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    DigitKey("1") { state.insert("1") }
                    DigitKey("2") { state.insert("2") }
                    DigitKey("3") { state.insert("3") }
                    OpKey("+") { state.op("+") }
                }
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    FuncKey("Ans") { state.insert("Ans") }
                    DigitKey("0") { state.insert("0") }
                    DigitKey(".") { state.dot() }
                    RoundKey("=", Modifier.weight(1f), Cyan, BgTop, 38.sp) { state.equals() }
                }
            }
        }

        if (showHistory) {
            HistoryPanel(
                state = state,
                onClose = { showHistory = false },
                onPick = {
                    state.insert(it)
                    showHistory = false
                }
            )
        }
    }
}

@Composable
fun HistoryPanel(state: CalcState, onClose: () -> Unit, onPick: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFA08153A))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Historial", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("Borrar", color = Cyan, fontSize = 16.sp, modifier = Modifier.clickable { state.clearHistory() }.padding(10.dp))
            Text("Cerrar", color = Cyan, fontSize = 16.sp, modifier = Modifier.clickable { onClose() }.padding(10.dp))
        }
        if (state.history.isEmpty()) {
            Text("Todavía no hay cálculos", color = Color(0xFF9FC3FF), fontSize = 16.sp, modifier = Modifier.padding(top = 24.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(state.history) { h ->
                Column(
                    Modifier.fillMaxWidth().clickable { onPick(h.result) }.padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(h.expr, color = Color(0xFF9FC3FF), fontSize = 16.sp)
                    Text(h.result, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Light)
                }
            }
        }
    }
}
